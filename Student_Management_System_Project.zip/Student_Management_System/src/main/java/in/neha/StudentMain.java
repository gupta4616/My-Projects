

package in.neha;

import java.sql.Connection;

import java.sql.PreparedStatement;

import java.sql.ResultSet;

import java.sql.SQLException;

import java.sql.Statement;

import java.util.Scanner;

public class StudentMain {

	public static void main(String[] args) throws SQLException {
		
		String uname = "admin";
		
		String upass = "admin@123";
		
		int num;
		
		char ch;
		
		Scanner sc = new Scanner(System.in);
		
		System.out.println("WELCOME TO EDUBRIDGE INDIA PVT LTD");
		System.out.println();
		
		System.out.println("1.ADMIN PORTAL");
		
		System.out.println("2.STUDENT PORTAL");
		
		System.out.println("... YOU ARE ...");
		num=sc.nextInt();
		
		
	    switch(num) {
		
	    case 1: // Admin Login
			
			    System.out.println("For Admin Login Enter The USERNAME & USERPASSWORD");
			
			    System.out.println("ENTER ADMIN NAME");
			    String un = sc.next();
			
			    System.out.println("ENTER ADMIN PASSWORD");
			    String up = sc.next();
			    
			       if(un.equals("admin") && up.equals("admin@123")) {
			    	   
			       
			    	 while(true) {
			     
			    System.out.println("********** ADMIN PORTAL **********");
		
		        System.out.println("_____HERE ADMIN OPERATIONS____");
		        
		        System.out.println("1. Show All Student Details");
		        
		        System.out.println("2. Delete Student Records");
		        
		        System.out.println("3. Update Student Details");
		        
		        System.out.println("Select Any");
		        int adminch=sc.nextInt();
		        
		           	 
	      switch(adminch) {
	   
	      case 1: // Display Students
	    	        
	    	      StudentOperations.displayAllStudent();
	    	      
		       break;
		      
	      case 2: // Delete Students 
		         
	    	      StudentOperations.deleteStudent();
		   
		       break;
		       
	      case 3: // Update Students 
		          
	    	      StudentOperations.updateStudent();
		      
		       break;
		       
	     default : System.out.println("Invalid Admin Option");
		       
	    }
	      
             System.out.println("Do You want to Continue  (Y/N)");
		  
		      ch=sc.next().charAt(0);
		   
		       if(ch=='n' || ch=='N')
		    	   
			        break;
		       
		}//while
	         
	          
	    }//if
			    	
	          else {
    	   
    	         System.out.println("Invalid !!!!!!!!!!!!!");
    	   
    	         System.out.println("YOU ARE NOT ADMIN");
    	   
        }
			     
	                break;	//case 1
	              
	         
		case 2:  // STUDENT LOGIN
			
			          while(true) {
			        	  
			    System.out.println(" ********** STUDENT PORTAL ********** ");
			    
                System.out.println("1. You Are Already Registerd");
                
                System.out.println("2. You Are New User");
			    
			    System.out.println("Choose Correct Option");
			    int chr = sc.nextInt();
			    
                     if(chr==1) {
			 
			    //String sel = "select * from StudentInformation where Student_Id="+Student_Id;
			    	System.out.println("Enter your choice");
						
			    	   System.out.println("2.Show Your Record");
			    	      
			    	   System.out.println("3.Update Your Record");
			    		int studentch = sc.nextInt();
			    		
			    switch(studentch) {
			    
			    case 2: // Show particular Record
					         
				    	 StudentOperations.displayParticularStudent();
				    	     
					          break;
					      
			    case 3: // update only ur information
					   
				    	 StudentOperations.updateParticularStudent();
					   
					         break;
					     
			    }
			    	   
			}
					  
			    else {
			    	
			    	System.out.println("Invalid Id !!!!!");
			    	
		    }
						    
			        if(chr==2) {
			    	
			    	System.out.println("HERE ARE COURSES");
			    	
			    	System.out.println("Enroll Now");
			    	
				    System.out.println();
				    	
				    System.out.println("__________COURSE LIST_________");
				    
				    System.out.println("FULL COUSE DETAILS");
				    
				    StudentOperations.courseList();
				    
				   
				    System.out.println("DO U WANT TO ENROLL FOR THIS COURSE   (Y/N)");
				    
				    ch=sc.next().charAt(0);
					  
				        if(ch == 'n' || ch == 'N') 
				    	   
					        break;
				        
				        if(ch == 'y' || ch == 'Y') 
				       
				        	
						System.out.println("1.Enroll for Course");
							 
						int studentch = sc.nextInt();
						
				 
		   switch(studentch) {
	       
	       case 1:// Insert Record 
	    	     
	    	     StudentOperations.insetStudent();

		       break;
		   
	      default : System.out.println("Invalid Student Operation");
	  
		  }
		
        }
			        
			    System.out.println("Do You want to Continue  (Y/N)");
			    
			    char sch=sc.next().charAt(0);
			    
			    if(sch=='n' || sch=='N') {
			    	
			    	break;
			    	    
			}
			    
	     }//while(student)	    
					    
      }//switch
				    
    }//main
		    		    
  }//class 



	
