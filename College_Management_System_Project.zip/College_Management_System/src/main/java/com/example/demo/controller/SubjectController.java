package com.example.demo.controller;


import java.util.List;

import javax.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import com.example.demo.entity.Subject;
import com.example.demo.error.StudentNotFoundException;
import com.example.demo.error.SubjectNotFoundException;
import com.example.demo.error.TeacherNotFoundException;
import com.example.demo.service.SubjectService;

@RestController
public class SubjectController {
	
	 @Autowired
	 private SubjectService subjectService;
	
	 
	 @PostMapping("/subject")
	 public ResponseEntity<Subject> addSubject( @Valid @RequestBody Subject subject) {
		 
		Subject sub = subjectService.addSubject(subject) ; 
		
		return new ResponseEntity<Subject>(sub, HttpStatus.CREATED);
	 }
     
	 
	 @GetMapping("/subject")
	 public List<Subject> getAllSubject() {
		 
		return subjectService.getAllSubject();	 
	 }
	 
	 
	 @DeleteMapping("/subject/{subid}")
	 public String deleteById(@PathVariable("subid") Integer subid) throws SubjectNotFoundException {
		 
		 subjectService.deleteById(subid);
		 
		 return "Record Deleted Sucessfully";	 
	 }
	 
	 
	 @PutMapping("/subject/{subid}")
     public Subject updateSubject(@PathVariable("subid")Integer subid, @RequestBody Subject subject) throws SubjectNotFoundException {
		 
		return subjectService.updateSubject(subid,subject);	 
	 }
	 
	 
	 //assign subject to student
	 @PutMapping("/subject/{subid}/student/{stuid}")
	 public Subject assignStudentToSubject(@PathVariable("Subid")Integer subid, @PathVariable("stuid")Integer stuid) throws SubjectNotFoundException, StudentNotFoundException {
		 
		return subjectService.assignStudentToSubject(subid, stuid); 
	 }
	 
	 
	 //assign subject to teacher
	 @PutMapping("subject/{subid}/teacher/{tid}")
	 public Subject assignTeacherToSubject(@PathVariable("subid")Integer subid, @PathVariable("tid")Integer tid) throws TeacherNotFoundException, SubjectNotFoundException {
		 
		return subjectService.assignTeacherToSubject(subid,tid);	 
	 }
	 
	 
	 @GetMapping("/subject/{subid}")
	 public Subject findById(@PathVariable("subid") Integer subid) throws SubjectNotFoundException {
		 
		return subjectService.findById(subid);	 
	 }
	 
	 
	 @GetMapping("/subjectname/{name}")
	 public Subject findBySubjectName(@PathVariable("name")String subjectName) throws SubjectNotFoundException {
		 
		 return subjectService.findBySubjectName(subjectName);
	 }	 
}
