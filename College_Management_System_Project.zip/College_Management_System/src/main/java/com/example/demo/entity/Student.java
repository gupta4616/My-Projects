package com.example.demo.entity;

import java.util.HashSet;

import java.util.Set;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.validation.constraints.Email;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
public class Student {
	 
	 @Id
	 @GeneratedValue(strategy = GenerationType.IDENTITY)
	 private Integer studentId;
	 
	 @NotEmpty
	 @Size(min=3, max=30, message= "Name should be min 3 aur max 30 character")
     private String studentName;
	 
	 @NotEmpty
	 @Min(value=10, message= "Mobile Number should be 10 digit")
	 private String studentMobileNo;
	 
	 @NotEmpty
	 private String studentAddress;
	 
	 @Email
	 @NotEmpty
	 private String studentEmailId;
	 
	 @Min(value=17, message= "Age should be 18 aur more than 18")
	 private Integer studentAge;
	 
	 @NotNull
	 private Float studentFees;
	 
	 
	 //relation with subject
	 @JsonIgnore
	 @ManyToMany(mappedBy ="Student_Subject")
		
	 private Set<Subject> subjects= new HashSet<>();

 
	public Set<Subject> getSubjects() {
		return subjects;
	}

	public void setSubjects(Set<Subject> subjects) {
		this.subjects = subjects;
	}

	public Integer getStudentId() {
		return studentId;
	}

	public void setStudentId(Integer studentId) {
		this.studentId = studentId;
	}

	public String getStudentName() {
		return studentName;
	}

	public void setStudentName(String studentName) {
		this.studentName = studentName;
	}

	public String getStudentMobileNo() {
		return studentMobileNo;
	}

	public void setStudentMobileNo(String studentMobileNo) {
		this.studentMobileNo = studentMobileNo;
	}

	public String getStudentAddress() {
		return studentAddress;
	}

	public void setStudentAddress(String studentAddress) {
		this.studentAddress = studentAddress;
	}

	public String getStudentEmailId() {
		return studentEmailId;
	}

	public void setStudentEmailId(String studentEmailId) {
		this.studentEmailId = studentEmailId;
	}

	public Integer getStudentAge() {
		return studentAge;
	}

	public void setStudentAge(Integer studentAge) {
		this.studentAge = studentAge;
	}

	public Float getStudentFees() {
		return studentFees;
	}

	public void setStudentFees(Float studentFees) {
		this.studentFees = studentFees;
	}
	
}
